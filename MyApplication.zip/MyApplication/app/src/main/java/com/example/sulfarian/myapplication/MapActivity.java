package com.example.sulfarian.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import android.widget.Button;


public class MapActivity extends AppCompatActivity {

    ImageView imgClick;
    Button bSaturn;
    Button bKik;
    Button bMueller;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        imgClick = findViewById(R.id.og);
        bSaturn = findViewById(R.id.saturn);
        bKik = findViewById(R.id.kik);
        bMueller = findViewById(R.id.mueller);

//        imgClick.setOnClickListener(new View.OnClickListener() {

  //          @Override
//            public void onClick(View v){
//                Toast.makeText (MapActivity.this, "Clicked", Toast.LENGTH_LONG).show();
//            }
//        });
        bSaturn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v){
                Toast.makeText (MapActivity.this, "Saturn", Toast.LENGTH_LONG).show();
            }
        });
        bKik.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v){
                Toast.makeText (MapActivity.this, "kik", Toast.LENGTH_LONG).show();
            }
        });
        bMueller.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v){
                Toast.makeText (MapActivity.this, "Mueller", Toast.LENGTH_LONG).show();
            }
        });
    }

}
